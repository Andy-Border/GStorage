python tuneGSR.py -dcora -g0 -t0 -eFineTune -v

#python tuneGSR.py -dairport -g0 -t0 -eFineTune -v

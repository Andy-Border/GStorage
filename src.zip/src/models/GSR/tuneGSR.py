import os.path as osp
import sys

sys.path.append((osp.abspath(osp.dirname(__file__)).split('src')[0] + 'src'))
import utils.util_funcs as uf
from utils.tune_utils import *
from models.GSR.trainGSR import train_GSR
from models.GSR.config import GSRConfig
import argparse
import numpy as np

rm_ratio_list = [0, 0.05, 0.1, 0.2, 0.4, 0.6]
rm_ratio_list = [0, 0.2, 0.4, 0.6]
add_ratio_list = [0, 1.0, 2.0]
add_ratio_list = [0, 0.25, 0.5, 0.75, 1.0, 1.5, 2.0]
zero_to_one_rough_list = [0, 0.25, 0.5, 0.75, 1.0]
zero_to_half_rough_list = [0, 0.25, 0.5]
small_list = [0, 0.25, 0.5]
fsim_weight_list = [0, 0.25, 0.5, 0.75, 1.0]
p_epoch_list = [100, 0, 5, 10, 20, 50, 100]
zero_to_one_fine_list = [0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]
# rm_cand_ratio = [0, 0.025, 0.05]
# add_cand_ratio = [0, 0.05, 0.1]
# filter_mode_list = [f'Mod_{i}_{j}' for i in rm_cand_ratio for j in add_cand_ratio]
c_conf_dict = {  # 50 x Trials
    'semb': 'dw',
    'fsim_weight': zero_to_one_rough_list,  # 5
    'intra_weight': zero_to_one_rough_list,  # 5
    'fsim_norm': True,
    'stochastic_trainer': False,
    'activation': ['Relu', 'Elu'],
    'p_batch_size': [128, 256, 512],
    'p_schedule_step': [0, 100, 250, 500, 1000]

}
fan_out_list = ['1_2', '3_5', '5_10', '10_20', '15_30', '20_40', '30_50']
EXP_DICT = {
    'RoughTune': {
        'common_configs': c_conf_dict
        ,
        'data_spec_configs': {
            'fan_out': {
                'cora': '20_40',  # 5
                'citeseer': '10_20',  # 5
                'airport': '5_10',  # 2
                'blogcatalog': '15_30',
                'flickr': '15_30',
                'arxiv': '5_10',
            },
            'add_ratio': {
                'cora': zero_to_one_rough_list,  # 5
                'citeseer': zero_to_one_rough_list,  # 5
                'airport': [0.0, 0.25, 0.5, 0.75, 1.0, 1.25, 1.5],  # 2
                'blogcatalog': [0.0, 0.1, 0.2, 0.3, 0.4, 0.5],
                'flickr': [0.0, 0.1, 0.2, 0.3],
                'arxiv': [0.0, 0.1, 0.2],

            },
            'rm_ratio': {
                'cora': [0.0],  # 2
                'citeseer': [0.0],
                'airport': [0.0, 0.25, 0.5],
                'blogcatalog': [0.0, 0.1, 0.2, 0.3],
                'flickr': [0.0, 0.1, 0.2, 0.3],
                'arxiv': [0.0, 0.05, 0.1],
            },
            'p_epochs': {
                'cora': [100, 10, 20, 30, 40, 50, 100],
                'citeseer': [0, 50, 100, 150, 200, 250, 300],
                'airport': [10, 20, 30, 40, 50, 100],
                'blogcatalog': [5, 1, 3, 5],
                'flickr': [5, 1, 3, 5],
                'arxiv': [3, 1, 2, 3]
            },
        },
    },

    'DETune': {
        'common_configs': c_conf_dict
        ,
        'data_spec_configs': {
            'fan_out': {
                'cora': '20_40',  # 5
                'citeseer': '10_20',  # 5
                'airport': '5_10',  # 2
                'blogcatalog': '15_30',
                'flickr': '15_30',
                'arxiv': '5_10',
            },
            'add_ratio': {
                'cora': zero_to_one_rough_list,  # 5
                'citeseer': zero_to_one_fine_list,  # 5
                'airport': [0.0, 0.25, 0.5, 0.75, 1.0, 1.25, 1.5],  # 2
                'blogcatalog': [0.0, 0.1, 0.2, 0.3, 0.4, 0.5],
                'flickr': [0.0, 0.1, 0.2, 0.3],
                'arxiv': [0.0, 0.1, 0.2],

            },
            'rm_ratio': {
                'cora': [0.0],  # 2
                'citeseer': [0.0],
                'airport': [0, 0.25, 0.5],
                'blogcatalog': [0.0, 0.1, 0.2, 0.3],
                'flickr': [0.0, 0.1, 0.2, 0.3],
                'arxiv': [0.0, 0.05, 0.1],
            },
            'p_epochs': {
                'cora': [100, 10, 20, 30, 40, 50, 100],
                'citeseer': [300, 50, 100, 150, 200, 250, 300],
                'airport': [50, 10, 20, 30, 40, 50],
                'blogcatalog': [5, 1, 3, 5],
                'flickr': [5, 1, 3, 5],
                'arxiv': [2, 1, 2]
            },

            'se_k': {
                'cora': ['full'],
                'citeseer': [7, 63, 127],
            },
        },
    },

    'ReluTune': {
        'common_configs':
            {  # 50 x Trials
                'fsim_weight': zero_to_one_rough_list,  # 5
                'intra_weight': zero_to_one_rough_list,  # 5
                'fsim_norm': True,
                'stochastic_trainer': False,
                'activation': 'Relu',
                'p_batch_size': [128, 256, 512],
            },

        'data_spec_configs': {
            'fan_out': {
                'cora': '20_40',  # 5
                'citeseer': '10_20',  # 5
                'pubmed': '3_5',  # 2
            },
            'add_ratio': {
                'cora': zero_to_one_rough_list,  # 5
                'citeseer': zero_to_one_rough_list,  # 5
                'pubmed': [0, 0.01],  # 2
            },
            'rm_ratio': {
                'cora': [0.0],  # 2
                'citeseer': [0.0],
                'pubmed': [0, 0.25, 0.5, 0.75, 1.0, 1.5, 2.0],
            },

            'p_epochs': {
                'cora': [50, 0, 10, 20, 30, 50],  # 5
                'citeseer': [200, 0, 50, 100, 150, 200],  # 4
                'arxiv': [3, 1, 3],  # 2
                'airport': [5, 10, 15],
                'blogcatalog': [3, 1, 3],
                'flickr': [3, 1, 3],
            },
        },
    },

    'EluTune': {
        'common_configs':
            {  # 50 x Trials
                'fsim_weight': zero_to_one_rough_list,  # 5
                'intra_weight': zero_to_one_rough_list,  # 5
                'fsim_norm': True,
                'stochastic_trainer': False,
                'activation': 'Elu',
                'p_batch_size': [128, 256, 512],
            },

        'data_spec_configs': {
            'fan_out': {
                'cora': '20_40',  # 5
                'citeseer': '10_20',  # 5
                'pubmed': '3_5',  # 2
            },
            'add_ratio': {
                'cora': zero_to_one_rough_list,  # 5
                'citeseer': zero_to_one_rough_list,  # 5
                'pubmed': [0, 0.01],  # 2
            },
            'rm_ratio': {
                'cora': [0.0],  # 2
                'citeseer': [0.0],
                'pubmed': [0, 0.25, 0.5, 0.75, 1.0, 1.5, 2.0],
            },
            'p_epochs': {
                'cora': [50, 0, 10, 20, 30, 50],  # 5
                'citeseer': [200, 0, 50, 100, 150, 200],  # 4
                'arxiv': [2],  # 2
                'airport': [5, 10, 15],
            },
        },
    },

    'FanoutPepochTune': {
        'common_configs': {
            'fan_out': fan_out_list,
            'p_epochs': [5, 0, 1, 2, 3, 4, 5],
            'fsim_weight': [0.5],
            'intra_weight': [0.5],
        }
        , 'data_spec_configs': {
            'add_ratio': {
                'cora': [1.0],
                'citeseer': 0.25,
                'pubmed': [0, 0.01],
            },
            'rm_ratio': {
                'cora': [0],
                'citeseer': [0],
                'pubmed': [0],
            }
        },
    },
    'SmallEpoch': {
        'common_configs': {
            'fan_out': fan_out_list,
            'p_epochs': [1, 2, 3, 4, 5],
            'fsim_weight': [0.5],
            'intra_weight': [0.5],
        }
        , 'data_spec_configs': {
            'add_ratio': {
                'cora': [1.0],
                'citeseer': 0.25,
                'pubmed': [0, 0.005, 0.01],
            },
        },
    },
    'FineTune': {
        'common_configs': {  # 25 x Trials
            'fsim_weight': zero_to_one_rough_list,  # 5
            'intra_weight': zero_to_one_rough_list,  # 5
            'fsim_norm': True,
            'stochastic_trainer': False,
            'activation': 'Elu',
        },
        'data_spec_configs': {
            'fan_out': {
                'cora': '20_40',
                'citeseer': '1_2',
                'airport': '5_10',
                'blogcatalog': '15_30',
                'flickr': '15_30',
                'arxiv': '5_10',
            },
            'add_ratio': {
                'cora': [0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0],  # 5
                'citeseer': [0.0, 0.25, 0.5, 0.75, 1.0, 1.25, 1.5],  # 5
                'airport': [0.0, 0.25, 0.5, 0.75, 1.0, 1.25, 1.5],
                'blogcatalog': [0.0, 0.1, 0.2, 0.3, 0.4, 0.5],
                'flickr': [0.0, 0.1, 0.2, 0.3],
                'arxiv': [0.0, 0.1, 0.2],
            },
            'p_epochs': {
                'cora': [40, 20, 25, 30, 35, 40],  # 2
                'citeseer': [150, 50, 100, 150],  # 4
                'airport': [20, 5, 10, 15, 20],
                'blogcatalog': [3, 1, 3],
                'flickr': [3, 1, 3],
            },
            'rm_ratio': {
                'cora': [0.0],
                'citeseer': [0.0],
                'airport': [0.0, 0.1, 0.2, 0.3, 0.4, 0.5],
                'blogcatalog': [0.0, 0.1, 0.2, 0.3],
                'flickr': [0.0, 0.1, 0.2, 0.3],
                'arxiv': [0.0, 0.05, 0.1],
            },
            'p_batch_size': {
                'cora': [128, 256, 512],
                'citeseer': [128, 256, 512],
                'airport': [128, 256, 512],
                'blogcatalog': [128, 256, 512],
                'flickr': [128, 256, 512],
                'arxiv': [512, 1024, 2048, 4096],
            },
        },
    },

    'tune_alpha': {
        'common_configs': {  # 50 x Trials
            'intra_weight': zero_to_one_rough_list,  # 5
        }
    },
    'tune_beta': {
        'common_configs': {  # 50 x Trials
            'fsim_weight': zero_to_one_rough_list,  # 5
        }
    },

    'FinalTune2': {
        'common_configs': {  # 25 x Trials
            'intra_weight': zero_to_one_rough_list,  # 5
            'fsim_weight': zero_to_one_rough_list,  #5
            'fsim_norm': True,
            'stochastic_trainer': False,

        },
        'data_spec_configs': {
            'fan_out': {
                'cora': '20_40',
                'citeseer': '1_2',
                'arxiv': '5_10',
                'airport': '5_10'
            },
            'add_ratio': {
                'cora': zero_to_one_rough_list,  # 5
                'citeseer': zero_to_one_rough_list,  # 5
                'arxiv': [0, 0.5, 1.0],  # 3
                'airport': zero_to_one_rough_list,
            },
            'p_epochs': {
                'cora': [20, 30, 35, 40, 50],  # 5
                'citeseer': [50, 100, 150],  # 4
                'arxiv': [2],  # 2
                'airport': [5, 10, 15],
            },
            'rm_ratio': {
                'cora':[0.0],
                'citeseer': [0.0],
                'arxiv': [0.0, 0.1, 0.2],
                'airport': [0.0, 0.1, 0.2],
            },
            'pre_batch_size': {
                'cora': [128, 256, 512, 1024],
                'citeseer': [128, 256, 512, 1024],
                'arxiv': [1024],
                'airport': [512, 1024],
            },
            'prt_lr': {
                'cora': [0.01, 0.001, 0.005],
                'citeseer': [0.01, 0.001, 0.005],
                'arxiv': [0.001],
                'airport': [0.001, 0.005]
            },
            'activation': {
                'cora': ['Relu', 'Elu'],
                'citeseer': ['Relu', 'Elu'],
                'arxiv': ['Relu'],
                'airport': ['Relu', 'Elu'],
            },
        },
    },

    'CoraEdgeTune1': {
        'common_configs': {  # 25 x Trials
            'intra_weight': [0.5],  # 5
            'fsim_weight': [0.0, 0.5, 1.0],
            'p_epochs': [35],
            'fan_out': '20_40',
            'fsim_norm': True,
            'stochastic_trainer': False,
            },
        'data_spec_configs': {
            'add_ratio': {
                'cora': np.arange(0, 1.01, 0.01).tolist()
            },
            'rm_ratio': {
                'cora': np.arange(0, 0.25, 0.01).tolist()
            },
        },
    },
    'CoraEdgeTune2': {
        'common_configs': {
            'intra_weight': [0.5],  # 5
            'fsim_weight': [0.0, 0.5, 1.0],
            'p_epochs': [35],
            'fan_out': '20_40',
            'fsim_norm': True,
            'stochastic_trainer': False,
            },
        'data_spec_configs': {
            'add_ratio': {
                'cora': np.arange(0, 1.01, 0.01).tolist()
            },
            'rm_ratio': {
                'cora': np.arange(0.25, 0.51, 0.01).tolist()
            },
        },
    },

    'CiteseerEdgeTune1': {
        'common_configs': {
            'intra_weight': [0.75],  # 5
            'fsim_weight': [0.0, 0.5, 1.0],
            'p_epochs': [100],
            'fan_out': '1_2',
            'fsim_norm': True,
            'stochastic_trainer': False,
            },
        'data_spec_configs': {
            'add_ratio': {
                'citeseer': np.arange(0, 1.01, 0.01).tolist()
            },
            'rm_ratio': {
                'citeseer': np.arange(0.0, 0.25, 0.01).tolist()
            },
        },
    },
    'CiteseerEdgeTune2': {
        'common_configs': {
            'intra_weight': [0.75],  # 5
            'fsim_weight': [0.0, 0.5, 1.0],
            'p_epochs': [100],
            'fan_out': '1_2',
            'fsim_norm': True,
            'stochastic_trainer': False,
            },
        'data_spec_configs': {
            'add_ratio': {
                'citeseer': np.arange(0, 1.01, 0.01).tolist()
            },
            'rm_ratio': {
                'citeseer': np.arange(0.25, 0.51, 0.01).tolist()
            },
        },
    },

    'EdgeTune': {
        'common_configs': {
            'add_ratio': [0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0],
            'rm_ratio': [0.0, 0.05, 0.1, 0.15, 0.2, 0.25, 0.3, 0.35, 0.4, 0.45, 0.5],
            'fsim_weight': [0.0, 0.5, 1.0],
            'fsim_norm': True,
            'stochastic_trainer': False,
            },
        'data_spec_configs': {
            'intra_weight': {
                'airport': [0.5],
                'blogcatalog': [0.75],
                'flickr': [0.25],
                'arxiv': [0.5],
            },
            'p_epochs': {
                'airport': [15],
                'blogcatalog': [3],
                'flickr': [1],
                'arxiv': [2],
            },
            'fan_out': {
                'airport': ['5_10'],
                'blogcatalog': ['15_30'],
                'flickr': ['15_30'],
                'arxiv': ['5_10'],
            },
        'activation': {
                'airport': ['Relu'],
                'blogcatalog': ['Relu'],
                'flickr': ['Relu'],
                'arxiv': ['Relu'],
            },
        },
    },

    'Test': {
        'common_configs': {
            'p_epochs': p_epoch_list,
            # 'fsim_weight': zero_to_one_rough_list,
        }

    }
}
model = 'GSR'

@uf.time_logger
def tune_mgsl():
    # * =============== Init Args =================
    # exp_name = 'PretrainTune'
    # exp_name = 'Test'
    exp_name = 'RoughTune'
    # exp_name = 'ReluTune'
    dataset = 'cora'
    parser = argparse.ArgumentParser()
    parser.add_argument('-r', '--run_times', type=int, default=5)
    parser.add_argument('-s', '--start_ind', type=int, default=0)
    parser.add_argument('-v', '--reverse_iter', action='store_true', help='reverse iter or not')
    parser.add_argument('-b', '--log_on', action='store_true', help='show log or not')
    parser.add_argument('-d', '--dataset', type=str, default=dataset)
    parser.add_argument('-e', '--exp_name', type=str, default=exp_name)
    parser.add_argument('-g', '--gpu', type=int, default=0)
    parser.add_argument('-t', '--train_percentage', type=int, default=0)
    parser.add_argument('-o', '--gnn_type', type=str, default='GraphSage')
    args = parser.parse_args()
    args.__dict__.update({'model': model, 'config': GSRConfig})

    # if '192.168.0' in get_ip():
    #     print('!!!' * 10 + 'Running on local, only CPU is used')
    #     args.gpu = -1
    # * =============== Fine Tune (grid search) =================
    print(args.exp_name)
    EXP_DICT[args.exp_name]['common_configs']['gnn_model'] = args.gnn_type
    tuner = Tuner(args, exp_dict=EXP_DICT[args.exp_name], default_dict=PARA_DICT)
    tune_df = tuner.tune_df
    print(tuner)

    exp_settings = ['run_times', 'start_ind', 'reverse_iter']
    ad = args.__dict__
    trial_settings = {k: ad[k] for k in ad if k not in exp_settings}
    grid_search(args, train_GSR, tune_df, trial_settings)
    # * =============== Result Summary  =================

    summarize_by_tune_df(tuner, trial_settings)


if __name__ == '__main__':
    tune_mgsl()

# tu -dcora -t1 -eFineTune1 -g0; tu -dcora -t3 -eFineTune1 -g0; tu -dcora -t5 -eFineTune1 -g0; tu -dcora -t10 -eFineTune1 -g0;
# tu -dcora -t10 -eFineTune1 -g1 -v; tu -dcora -t5 -eFineTune1 -g1 -v; tu -dcora -t3 -eFineTune1 -g1 -v; tu -dcora -t1 -eFineTune1 -g1 -v;

# tu -dcora -t1 -eFanoutPepochTune -g0; tu -dcora -t3 -eFanoutPepochTune -g0; tu -dcora -t5 -eFanoutPepochTune -g0; tu -dcora -t10 -eFanoutPepochTune -g0;
# tu -dcora -t10 -eFanoutPepochTune -g1 -v; tu -dcora -t5 -eFanoutPepochTune -g1 -v; tu -dcora -t3 -eFanoutPepochTune -g1 -v; tu -dcora -t1 -eFanoutPepochTune -g1 -v;

# tu -dciteseer -t1 -eFineTune1 -g0; tu -dciteseer -t3 -eFineTune1 -g0; tu -dciteseer -t5 -eFineTune1 -g0; ; tu -dciteseer -t10 -eFineTune1 -g0;
# tu -dciteseer -t10 -eFineTune1 -g1 -v; tu -dciteseer -t5 -eFineTune1 -g1 -v; tu -dciteseer -t3 -eFineTune1 -g1 -v; tu -dciteseer -t1 -eFineTune1 -g1 -v;

# tu -dpubmed -t1 -eFanoutPepochTune -g0; tu -dpubmed -t3 -eFanoutPepochTune -g0; tu -dpubmed -t5 -eFanoutPepochTune -g0;  tu -dpubmed -t10 -eFanoutPepochTune -g0;
# tu -dpubmed -t10 -eFanoutPepochTune -g1 -v; tu -dpubmed -t5 -eFanoutPepochTune -g1 -v; tu -dpubmed -t3 -eFanoutPepochTune -g1 -v; tu -dpubmed -t1 -eFanoutPepochTune -g1 -v;


# tu -dciteseer -t1 -eRoughTune -g1; tu -dciteseer -t3 -eRoughTune -g1; tu -dciteseer -t5 -eRoughTune -g1; tu -dciteseer -t10 -eRoughTune -g1;
# tu -dciteseer -t10 -eRoughTune -g0 -v; tu -dciteseer -t5 -eRoughTune -g0 -v; tu -dciteseer -t3 -eRoughTune -g0 -v; tu -dciteseer -t1 -eRoughTune -g0 -v;


# tu -dciteseer -t1 -eRoughTune -g1; tu -dciteseer -t3 -eRoughTune -g1; tu -dciteseer -t10 -eRoughTune -g1;
# tu -dciteseer -t10 -eRoughTune -g0 -v; tu -dciteseer -t3 -eRoughTune -g0 -v; tu -dciteseer -t1 -eRoughTune -g0 -v;


# tu -dpubmed -t1 -eRoughTune -g1; tu -dpubmed -t3 -eRoughTune -g1;
# tu -dpubmed -t3 -eRoughTune -g0 -v; tu -dpubmed -t1 -eRoughTune -g0 -v;


# tu -dcora -t1 -ePretrainTune -g1 -v
# tu -dcora -t5 -ePretrainTune -g1
# tu -dcora -t10 -ePretrainTune -g1 -v

# tu -dpubmed -eRoughTune -g0 -t1
# tu -dpubmed -ePretrainTune -g0 -t5
# tu -dpubmed -eRoughTune -g0 -t10

# python /home/zja/PyProject/MGSL/src/models/MGSL/sum_results.py


# PR-_lr0.01_bsz512_pi1_encGCN_dec-l2_hidden48-prt_intra_w-1.0_ncek16382_fanout15_30_prdo0_act_Elu_d64_pdlFalse_GR-fsim_norm1_fsim_weight0.0_add0.5_rm0.0
# l0_PR-_lr0.01_bsz256_pi3_encGCN_dec-l2_hidden48-prt_intra_w-0.75_ncek16382_fanout15_30_prdo0_act_Elu_d64_pdlFalse-_GR-fsim_norm1_fsim_weight1.0_add0.4_rm0.3_lr0.01_GCN-do0.5


########################Aug 06 GNN backbone##########################

###cora
# tu -dcora -t0 -eRoughTune -g0 -oGCN;
# tu -dcora -t0 -eRoughTune -g0 -oGAT;
# tu -dcora -t0 -eRoughTune -g0 -oGraphSage;
# tu -dcora -t0 -eRoughTune -g0 -oGCNII;

### citeseer
# tu -dciteseer -t0 -eRoughTune -g0 -oGCN;
# tu -dciteseer -t0 -eRoughTune -g0 -oGAT;
# tu -dciteseer -t0 -eRoughTune -g0 -oGraphSage;
# tu -dciteseer -t0 -eRoughTune -g0 -oGCNII;

### airport
# tu -dairport -t0 -eRoughTune -g0 -oGCN;
# tu -dairport -t0 -eRoughTune -g0 -oGAT;
# tu -dairport -t0 -eRoughTune -g0 -oGraphSage;
# tu -dairport -t0 -eRoughTune -g0 -oGCNII;

### blogcatalog
# tu -dblogcatalog -t0 -eRoughTune -g0 -oGCN;
# tu -dblogcatalog -t0 -eRoughTune -g0 -oGAT;
# tu -dblogcatalog -t0 -eRoughTune -g0 -oGraphSage;
# tu -dblogcatalog -t0 -eRoughTune -g0 -oGCNII;

### flickr
# tu -dflickr -t0 -eRoughTune -g0 -oGCN;
# tu -dflickr -t0 -eRoughTune -g0 -oGAT;
# tu -dflickr -t0 -eRoughTune -g0 -oGraphSage;
# tu -dflickr -t0 -eRoughTune -g0 -oGCNII;

### arxiv
# tu -darxiv -t0 -eRoughTune -g0 -oGCN;
# tu -darxiv -t0 -eRoughTune -g0 -oGAT;
# tu -darxiv -t0 -eRoughTune -g0 -oGraphSage;
# tu -darxiv -t0 -eRoughTune -g0 -oGCNII;

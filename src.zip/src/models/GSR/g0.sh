python tuneGSR.py -dcora -g0 -t0 -eFineTune

#python tuneGSR.py -dairport -g0 -t0 -eFineTune

python tuneGSR.py -dairport -g0 -t0 -eRoughTune
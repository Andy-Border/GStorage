#!/usr/bin/env python
# encoding: utf-8
# File Name: data_util.py
# Author: Jiezhong Qiu
# Create Time: 2019/12/30 14:20
# TODO:

import pickle
import dgl
import dgl.data
import numpy as np
import scipy
import scipy.sparse as sparse
import torch as th
import torch.nn.functional as F
from sklearn.model_selection import train_test_split
import utils.util_funcs as uf
from utils.conf_utils import Dict2Config
from utils.proj_settings import *
import argparse
import numpy as np
import scipy.sparse as sp
import torch
import random
import networkx as nx
import dgl
from dgl import DGLGraph
from dgl.data import *
from bidict import bidict
# from skmultilearn.model_selection import iterative_train_test_split
import torch_geometric.utils as tgu
from tqdm import tqdm

def graph_normalization(g, cuda):
    degs = g.in_degrees().float()
    norm = torch.pow(degs, -0.5)
    norm[torch.isinf(norm)] = 0
    if cuda:
        norm = norm.cuda()
    g.ndata['norm'] = norm.unsqueeze(1)
    return g


def stratified_train_test_split(label_idx, labels, num_nodes, train_rate, seed=2021):
    num_train_nodes = int(train_rate / 100 * num_nodes)
    test_rate_in_labeled_nodes = (len(labels) - num_train_nodes) / len(labels)
    train_idx, test_and_valid_idx = train_test_split(
        label_idx, test_size=test_rate_in_labeled_nodes, random_state=seed, shuffle=True, stratify=labels)
    valid_idx, test_idx = train_test_split(
        test_and_valid_idx, test_size=.5, random_state=seed, shuffle=True, stratify=labels[test_and_valid_idx])
    return train_idx, valid_idx, test_idx

# def multi_stratified_train_test_split(labels, num_nodes, train_rate, seed=2021):
#
#     label_idx = np.zeros((labels.shape[0], 2)).astype(int)
#     label_idx[:, 0]  += np.arange(labels.shape[0])
#
#     num_train_nodes = int(train_rate / 100 * num_nodes)
#     test_rate_in_labeled_nodes = (labels.shape[0] - num_train_nodes) / labels.shape[0]
#     train_idx, _, test_and_valid_idx, test_and_valid_labels = iterative_train_test_split(label_idx, labels, test_size=test_rate_in_labeled_nodes)
#     valid_idx, _, test_idx, _ = iterative_train_test_split(test_and_valid_idx, labels[test_and_valid_idx[:,0]], test_size=.5)
#
#     train_idx = np.sum(train_idx, 1)
#     valid_idx = np.sum(valid_idx, 1)
#     test_idx = np.sum(test_idx, 1)
#
#     return train_idx, valid_idx, test_idx


def preprocess_data(dataset, train_percentage, dev):
    # Modified from AAAI21 FA-GCN
    train_ratio = train_percentage / 100
    if dataset in ['cora', 'citeseer', 'pubmed']:
        load_default_split = train_percentage <= 0
        edge = np.loadtxt(f'{DATA_PATH}/{dataset}/{dataset}.edge', dtype=int).tolist()
        features = np.loadtxt(f'{DATA_PATH}/{dataset}/{dataset}.feature')
        labels = np.loadtxt(f'{DATA_PATH}/{dataset}/{dataset}.label', dtype=int)
        if load_default_split:
            train = np.loadtxt(f'{DATA_PATH}/{dataset}/{dataset}.train', dtype=int)
            val = np.loadtxt(f'{DATA_PATH}/{dataset}/{dataset}.val', dtype=int)
            test = np.loadtxt(f'{DATA_PATH}/{dataset}/{dataset}.test', dtype=int)
        else:
            train, val, test = stratified_train_test_split(np.arange(len(labels)), labels, len(labels), train_percentage)
        nclass = len(set(labels.tolist()))
        print(dataset, nclass)

        U = [e[0] for e in edge]
        V = [e[1] for e in edge]
        g = dgl.graph((U, V))
        g = dgl.to_simple(g)
        g = dgl.remove_self_loop(g)
        # g = dgl.to_bidirected(g)

        features = normalize_features(features)
        features = th.FloatTensor(features)
        labels = th.LongTensor(labels)
        train = th.LongTensor(train)
        val = th.LongTensor(val)
        test = th.LongTensor(test)

    elif dataset in ['airport', 'blogcatalog', 'flickr']:
        load_default_split = train_percentage <= 0
        adj_orig = pickle.load(open(f'{DATA_PATH}/{dataset}/{dataset}_adj.pkl', 'rb'))  # sparse
        features = pickle.load(open(f'{DATA_PATH}/{dataset}/{dataset}_features.pkl', 'rb'))  # sparase
        labels = pickle.load(open(f'{DATA_PATH}/{dataset}/{dataset}_labels.pkl', 'rb'))  # tensor
        if th.is_tensor(labels):
            labels = labels.numpy()

        if load_default_split:
            tvt_nids = pickle.load(open(f'{DATA_PATH}/{dataset}/{dataset}_tvt_nids.pkl', 'rb')) # 3 array
            train = tvt_nids[0]
            val = tvt_nids[1]
            test = tvt_nids[2]
        else:
            train, val, test = stratified_train_test_split(np.arange(len(labels)), labels, len(labels),
                                                           train_percentage)
        nclass = len(set(labels.tolist()))
        print(dataset, nclass)


        adj_orig = adj_orig.tocoo()
        U = adj_orig.row.tolist()
        V = adj_orig.col.tolist()
        g = dgl.graph((U, V))
        g = dgl.to_simple(g)
        g = dgl.remove_self_loop(g)
        g = dgl.to_bidirected(g)

        if dataset in ['airport']:
            features = normalize_features(features)

        if sp.issparse(features):
            features = torch.FloatTensor(features.toarray())
        else:
            features = th.FloatTensor(features)

        labels = th.LongTensor(labels)
        train = th.LongTensor(train)
        val = th.LongTensor(val)
        test = th.LongTensor(test)

    # elif dataset in ['ppi']:
    #     load_default_label = True
    #     adj_orig = pickle.load(open(f'{DATA_PATH}/{dataset}/{dataset}_adj.pkl', 'rb'))  # sparse
    #     features = pickle.load(open(f'{DATA_PATH}/{dataset}/{dataset}_features.pkl', 'rb'))  # sparase
    #     labels = pickle.load(open(f'{DATA_PATH}/{dataset}/{dataset}_labels.pkl', 'rb'))  # tensor
    #     labels = sp.lil_matrix(labels)
    #
    #
    #     if load_default_label:
    #         tvt_nids = pickle.load(open(f'{DATA_PATH}/{dataset}/{dataset}_tvt_nids.pkl', 'rb'))  # 3 array
    #         train = tvt_nids[0]
    #         val = tvt_nids[1]
    #         test = tvt_nids[2]
    #     else:
    #         train, val, test = multi_stratified_train_test_split(labels, labels.shape[0],
    #                                                        train_percentage)
    #
    #     nclass = labels.shape[1]
    #     print(dataset, nclass)
    #
    #     adj_orig = adj_orig.tocoo()
    #     U = adj_orig.row.tolist()
    #     V = adj_orig.col.tolist()
    #     g = dgl.graph((U, V))
    #     g = dgl.to_simple(g)
    #     g = dgl.remove_self_loop(g)
    #     g = dgl.to_bidirected(g)
    #
    #     if sp.issparse(features):
    #         features = torch.FloatTensor(features.toarray())
    #     else:
    #         features = th.FloatTensor(features)
    #
    #     labels = th.FloatTensor(labels.todense())
    #     train = th.LongTensor(train)
    #     val = th.LongTensor(val)
    #     test = th.LongTensor(test)

    elif dataset in ['film']:
        graph_adjacency_list_file_path = '../high_freq/{}/out1_graph_edges.txt'.format(dataset)
        graph_node_features_and_labels_file_path = '../high_freq/{}/out1_node_feature_label.txt'.format(dataset)

        G = nx.DiGraph()
        graph_node_features_dict = {}
        graph_labels_dict = {}

        if dataset == 'film':
            with open(graph_node_features_and_labels_file_path) as graph_node_features_and_labels_file:
                graph_node_features_and_labels_file.readline()
                for line in graph_node_features_and_labels_file:
                    line = line.rstrip().split('\t')
                    assert (len(line) == 3)
                    assert (int(line[0]) not in graph_node_features_dict and int(line[0]) not in graph_labels_dict)
                    feature_blank = np.zeros(932, dtype=np.uint16)
                    feature_blank[np.array(line[1].split(','), dtype=np.uint16)] = 1
                    graph_node_features_dict[int(line[0])] = feature_blank
                    graph_labels_dict[int(line[0])] = int(line[2])
        else:
            with open(graph_node_features_and_labels_file_path) as graph_node_features_and_labels_file:
                graph_node_features_and_labels_file.readline()
                for line in graph_node_features_and_labels_file:
                    line = line.rstrip().split('\t')
                    assert (len(line) == 3)
                    assert (int(line[0]) not in graph_node_features_dict and int(line[0]) not in graph_labels_dict)
                    graph_node_features_dict[int(line[0])] = np.array(line[1].split(','), dtype=np.uint8)
                    graph_labels_dict[int(line[0])] = int(line[2])

        with open(graph_adjacency_list_file_path) as graph_adjacency_list_file:
            graph_adjacency_list_file.readline()
            for line in graph_adjacency_list_file:
                line = line.rstrip().split('\t')
                assert (len(line) == 2)
                if int(line[0]) not in G:
                    G.add_node(int(line[0]), features=graph_node_features_dict[int(line[0])],
                               label=graph_labels_dict[int(line[0])])
                if int(line[1]) not in G:
                    G.add_node(int(line[1]), features=graph_node_features_dict[int(line[1])],
                               label=graph_labels_dict[int(line[1])])
                G.add_edge(int(line[0]), int(line[1]))

        adj = nx.adjacency_matrix(G, sorted(G.nodes()))
        row, col = np.where(adj.todense() > 0)

        U = row.tolist()
        V = col.tolist()
        g = dgl.graph((U, V))
        g = dgl.to_simple(g)
        g = dgl.to_bidirected(g)
        g = dgl.remove_self_loop(g)

        features = np.array([features for _, features in sorted(G.nodes(data='features'), key=lambda x: x[0])], dtype=float)
        labels = np.array([label for _, label in sorted(G.nodes(data='label'), key=lambda x: x[0])], dtype=int)

        n = labels.shape[0]
        idx = [i for i in range(n)]
        # random.shuffle(idx)
        r0 = int(n * train_ratio)
        r1 = int(n * 0.6)
        r2 = int(n * 0.8)

        idx_train = np.array(idx[:r0])
        idx_val = np.array(idx[r1:r2])
        idx_test = np.array(idx[r2:])

        features = normalize_features(features)
        features = th.FloatTensor(features)

        nclass = 5
        labels = th.LongTensor(labels)
        train = th.LongTensor(idx_train)
        val = th.LongTensor(idx_val)
        test = th.LongTensor(idx_test)
        print(dataset, nclass)
    # datasets in Geom-GCN
    elif dataset in ['cornell', 'texas', 'wisconsin', 'chameleon', 'squirrel']:

        graph_adjacency_list_file_path = '../high_freq/{}/out1_graph_edges.txt'.format(dataset)
        graph_node_features_and_labels_file_path = '../high_freq/{}/out1_node_feature_label.txt'.format(dataset)

        G = nx.DiGraph()
        graph_node_features_dict = {}
        graph_labels_dict = {}

        with open(graph_node_features_and_labels_file_path) as graph_node_features_and_labels_file:
            graph_node_features_and_labels_file.readline()
            for line in graph_node_features_and_labels_file:
                line = line.rstrip().split('\t')
                assert (len(line) == 3)
                assert (int(line[0]) not in graph_node_features_dict and int(line[0]) not in graph_labels_dict)
                graph_node_features_dict[int(line[0])] = np.array(line[1].split(','), dtype=np.uint8)
                graph_labels_dict[int(line[0])] = int(line[2])

        with open(graph_adjacency_list_file_path) as graph_adjacency_list_file:
            graph_adjacency_list_file.readline()
            for line in graph_adjacency_list_file:
                line = line.rstrip().split('\t')
                assert (len(line) == 2)
                if int(line[0]) not in G:
                    G.add_node(int(line[0]), features=graph_node_features_dict[int(line[0])],
                               label=graph_labels_dict[int(line[0])])
                if int(line[1]) not in G:
                    G.add_node(int(line[1]), features=graph_node_features_dict[int(line[1])],
                               label=graph_labels_dict[int(line[1])])
                G.add_edge(int(line[0]), int(line[1]))

        adj = nx.adjacency_matrix(G, sorted(G.nodes()))
        features = np.array([features for _, features in sorted(G.nodes(data='features'), key=lambda x: x[0])])
        labels = np.array([label for _, label in sorted(G.nodes(data='label'), key=lambda x: x[0])])

        features = normalize_features(features)

        g = DGLGraph(adj)
        g = dgl.to_simple(g)
        g = dgl.to_bidirected(g)
        g = dgl.remove_self_loop(g)

        n = len(labels.tolist())
        idx = [i for i in range(n)]
        # random.shuffle(idx)
        r0 = int(n * train_ratio)
        r1 = int(n * 0.6)
        r2 = int(n * 0.8)
        train = np.array(idx[:r0])
        val = np.array(idx[r1:r2])
        test = np.array(idx[r2:])

        nclass = len(set(labels.tolist()))
        features = th.FloatTensor(features)
        labels = th.LongTensor(labels)
        train = th.LongTensor(train)
        val = th.LongTensor(val)
        test = th.LongTensor(test)
        print(dataset, nclass)

    # datasets in FAGCN
    elif dataset in ['new_chameleon', 'new_squirrel']:
        edge = np.loadtxt('../high_freq/{}/edges.txt'.format(dataset), dtype=int)
        labels = np.loadtxt('../high_freq/{}/labels.txt'.format(dataset), dtype=int).tolist()
        features = np.loadtxt('../high_freq/{}/features.txt'.format(dataset), dtype=float)

        U = [e[0] for e in edge]
        V = [e[1] for e in edge]
        g = dgl.graph((U, V))
        g = dgl.to_simple(g)
        g = dgl.to_bidirected(g)
        g = dgl.remove_self_loop(g)

        n = len(labels)
        idx = [i for i in range(n)]
        # random.shuffle(idx)
        r0 = int(n * train_ratio)
        r1 = int(n * 0.6)
        r2 = int(n * 0.8)
        train = np.array(idx[:r0])
        val = np.array(idx[r1:r2])
        test = np.array(idx[r2:])

        features = normalize_features(features)
        features = th.FloatTensor(features)

        nclass = 3
        labels = th.LongTensor(labels)
        train = th.LongTensor(train)
        val = th.LongTensor(val)
        test = th.LongTensor(test)
        print(dataset, nclass)

    if dataset in ['citeseer']:
        g = dgl.remove_self_loop(g)
        g = dgl.add_self_loop(g)
    return g.to(dev), features.to(dev), features.shape[1], nclass, labels.to(dev), train.to(dev), val.to(dev), test.to(dev)


def normalize_features(mx):
    """Row-normalize sparse matrix"""

    rowsum = np.array(mx.sum(1))
    r_inv = np.power(rowsum, -1).flatten()
    r_inv[np.isinf(r_inv)] = 0.
    r_mat_inv = sp.diags(r_inv)
    mx = r_mat_inv.dot(mx)

    rowsum = np.array(mx.sum(1))
    zero_lines = np.nonzero(rowsum==0)[0]
    if len(zero_lines) > 0:
        mx[zero_lines, :] += 1e-8

    return mx


def mp_to_relations(mp):
    return [f"{mp[t_id]}{mp[t_id + 1]}" for t_id in range(len(mp) - 1)]


# def distance_encoding(g, semb_flag='sp', prop_depth=1, layers=2, max_sp=3):
#
#     src, dst = g.edges()
#     edge_index = torch.cat([src.unsqueeze(-1), dst.unsqueeze(-1)], dim=-1).t().long()
#     node_degree = g.in_degrees().cpu().numpy()
#     attributes = np.zeros((g.number_of_nodes(), 1), dtype=np.float32)
#     attributes += np.expand_dims(np.log(node_degree+1), 1).astype(np.float32)
#
#     set_indices = np.expand_dims(np.arange(g.number_of_nodes()), 1)
#     datalist = []
#     hop_num = int(prop_depth * layers) + 1
#     n_samples = set_indices.shape[0]
#     if semb_flag == 'sp':
#         for sample_i in tqdm(range(n_samples)):
#             set_index = list(set_indices[sample_i])
#             subgraph_node_old_index, new_edge_index, new_set_index, edge_mask = tgu.k_hop_subgraph(
#                 torch.tensor(set_index).long(), hop_num, edge_index, num_nodes=g.number_of_nodes(), relabel_nodes=True)
#
#             num_nodes = subgraph_node_old_index.size(0)
#             new_G = nx.from_edgelist(new_edge_index.t().numpy().astype(dtype=np.int32), create_using=type(nx.Graph()))
#             new_G.add_nodes_from(np.arange(num_nodes, dtype=np.int32))  # to add disconnected nodes
#             assert (new_G.number_of_nodes() == num_nodes)
#
#             x_list = []
#             if attributes is not None:
#                 new_attributes = torch.tensor(attributes, dtype=torch.float32)[subgraph_node_old_index]
#                 if new_attributes.dim() < 2:
#                     new_attributes.unsqueeze_(1)
#                 x_list.append(new_attributes)
#
#             features_sp_sample = get_features_sp_sample(new_G, new_set_index.numpy(), max_sp=max_sp)
#             features_sp_sample = torch.from_numpy(features_sp_sample).float()
#             x_list.append(features_sp_sample)
#             x = torch.cat(x_list, dim=-1)
#
#             datalist.append(x)
#
#     elif semb_flag == 'rw':
#         raise NotImplementedError
#
#     return datalist
#
# def get_features_sp_sample(G, node_set, max_sp):
#     dim = max_sp + 2
#     set_size = len(node_set)
#     sp_length = np.ones((G.number_of_nodes(), set_size), dtype=np.int32) * -1
#     for i, node in enumerate(node_set):
#         for node_ngh, length in nx.shortest_path_length(G, source=node).items():
#             sp_length[node_ngh, i] = length
#     sp_length = np.minimum(sp_length, max_sp)
#     onehot_encoding = np.eye(dim, dtype=np.float64)  # [n_features, n_features]
#     features_sp = onehot_encoding[sp_length].sum(axis=1)
#
#     return features_sp


def IntimacyScore(S, k):

    user_top_k_neighbor_intimacy_dict = {}
    for node_index in range(len(S)):
        s = S[node_index]
        s[node_index] = -1000.0
        top_k_neighbor_index = s.argsort()[-k:][::-1]
        user_top_k_neighbor_intimacy_dict[node_index] = []
        for neighbor_index in top_k_neighbor_index:
            user_top_k_neighbor_intimacy_dict[node_index].append((neighbor_index, s[neighbor_index]))

    return user_top_k_neighbor_intimacy_dict

def HopDistance(G, batch_dict):

    hop_dict = {}
    nx_G = dgl.to_networkx(G.cpu())
    hop_ids_list = []
    for node in batch_dict:
        hop_ids = [0]
        for neighbor, score in batch_dict[node]:
            try:
                hop = nx.shortest_path_length(nx_G, source=node, target=neighbor)
            except:
                hop = 99
            hop_ids.append(hop)
        hop_ids_list.append(hop_ids)

    hop_embeddings = torch.LongTensor(hop_ids_list)

        # if node not in hop_dict: hop_dict[node] = {}
        # for neighbor, score in batch_dict[node]:
        #     try:
        #         hop = nx.shortest_path_length(nx_G, source=node, target=neighbor)
        #     except:
        #         hop = 99
        #     hop_dict[node][neighbor] = hop

    return hop_embeddings


def DE_adj_normalize(mx):
    """Row-normalize sparse matrix"""
    rowsum = np.array(mx.sum(1))
    r_inv = np.power(rowsum, -0.5).flatten()
    r_inv[np.isinf(r_inv)] = 0.
    r_mat_inv = sp.diags(r_inv)
    mx = r_mat_inv.dot(mx).dot(r_mat_inv)
    return mx

def DistanceEncoding(graph, n_class, c=0.15):

    adj = graph.adj(scipy_fmt='coo')
    eigen_adj = c * np.linalg.inv((sp.eye(adj.shape[0]) - (1 - c) * DE_adj_normalize(adj)).toarray())
    norm_adj = DE_adj_normalize(adj + sp.eye(adj.shape[0]))
    intimacy_score_dict = IntimacyScore(eigen_adj, n_class)
    print(intimacy_score_dict)
    distance_embedding = HopDistance(graph, intimacy_score_dict)

    return distance_embedding

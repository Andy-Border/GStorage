### Generate the feature embedding and structure embedding
